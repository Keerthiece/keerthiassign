import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Chart from 'chart.js/auto';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  latestResults: any = [];
  daysData: Record<string, Record<string, number>> = {};
  sortedDays: string[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get<any>('https://mocki.io/v1/b8d69ada-908f-4d70-97a9-c7dba1b99126')
      .subscribe(data => {
        console.log('API Response:', data);
        this.latestResults = data?.dashboardData?.lastestResults || {};
        this.daysData = data?.dashboardData?.timeSpentData?.days || {};

        this.sortDays();
        this.createBarChart();
      });
  }

  parseScore(score: string): string {
    return parseInt(score, 10) + '%';
  }

  sortDays(): void {
    this.sortedDays = Object.keys(this.daysData).sort();
  }

  createBarChart() {
    const days = this.sortedDays;
    const datasets: any = [];
  
  
    const colors: { [key: string]: string } = {
      Vocabulary: 'red',
      Grammar: 'green',
      Listening: 'blue',
      Writing: 'gray'
    };
  

    Object.keys(colors).forEach(category => {
      const data = days.map(day => this.daysData[day][category]);
      datasets.push({
        label: category,
        data,
        backgroundColor: colors[category],
        barThickness: 5, 
        barPercentage: 0.8, 
        categoryPercentage: 0.9, 
      });
    });
  
  
    const ctx = document.getElementById('yourChart') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: days,
        datasets
      },
      options: {
        scales: {
          y: {
            stacked: true,
            beginAtZero: true,
            display: false, 
            ticks: {
              stepSize: 1, 
              
              callback: () => '' 
            }
          },
          x: {
            stacked: true,
           // display: false 
          }
        },
        plugins: {
          legend: {
            display: false 
          }
        },
        layout: {
          padding: {
            left: 20, 
            right: 20 
          }
        }
      }
    });
  }
  
  
  
  
  
}
