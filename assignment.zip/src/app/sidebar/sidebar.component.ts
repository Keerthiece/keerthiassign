import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent {

 @Output() menuItemSelected = new EventEmitter<string>();
 sidebarVisible: boolean = true; 

 
  onMenuItemClick(menuItem: string) {
    this.menuItemSelected.emit(menuItem);
  }

  toggleSidebar() {
    console.log('Before Toggle:', this.sidebarVisible);
    this.sidebarVisible = !this.sidebarVisible;
    console.log('After Toggle:', this.sidebarVisible);
  }
  
}
