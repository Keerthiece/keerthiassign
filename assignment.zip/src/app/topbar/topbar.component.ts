import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.css']
})
export class TopbarComponent implements OnInit{
  todate=new Date();
  @Input() selectedMenuItem: string | undefined;
  ngOnInit(){
    console.log(this.todate)
  }
  onMenuItemSelected(menuItem: string) {
    this.selectedMenuItem = menuItem;
  }
}
