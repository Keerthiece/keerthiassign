import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-rightbar',
  templateUrl: './rightbar.component.html',
  styleUrls: ['./rightbar.component.css']
})
export class RightbarComponent {
  imageUrl!: string;
  userdata:any=[];
  remainders:any=[];

  constructor(private http: HttpClient) {}
  
  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.imageUrl = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }

  ngOnInit() {
    
    this.http.get<any>('https://mocki.io/v1/b8d69ada-908f-4d70-97a9-c7dba1b99126')
      .subscribe(data => {
        this.userdata = data?.dashboardData?.userData[0];
        console.log(this.userdata)
        this.remainders= this.userdata.reminders;
        console.log(this.remainders,"this.remainders")
      });
     
  }

  getCourses(): string[] {
    return Object.keys(this.userdata?.courses || {});
  }
  parseScore(score: string): string {
    return parseInt(score, 10) + '%';
  }

}
